# PhoenixRPU

Custom rules for a Williams Phoenix (1978, System 4) running Dick Hamill's Retro Pin Upgrade (RPU) library on a System Alpha X1 board (Rev 200) with an Arduino Mega 2560.

- `PhoenixRPU/` - the Arduino sketch (open `PhoenixRPU.ino`; the folder name must match the sketch name). Current build: v21.
- `docs/CHANGELOG.txt` - version history v0 to v21 with diffs against the previous version and against v0.
- `tests/scenarios/` - simulator scenarios for [rpu-sim](https://github.com/wifijt/rpu-sim) (`machine.sim` plus one file per behavior checked).

Built on the RPU library and its examples (GPL, see `PhoenixRPU/LICENSE`).
