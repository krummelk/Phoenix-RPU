# Convert Kurt's Phoenix-split GIF frames (640x496) to 480x272 PNGs for the Nextion.
# - keeps every second frame (21 of 42), so the loop runs at the GIF's speed at 120 ms per frame
# - crops the top band (scan-line junk) and a little of the bottom, scales to 272 px high
# - the source GIF's background flips between blue-black and brown-black from frame to frame (palette);
#   dark background pixels are blended to one steady background so it doesn't flicker on the display
# - widens to 480 px with that same steady background
# - v2: the bird is scaled a little smaller and sits higher, with a glowing PHOENIX title underneath
from PIL import Image
import numpy as np, glob, os
os.makedirs('out', exist_ok=True)
Y0, Y1 = 45, 465
H = 272; BH = 222; TOPY = 4                           # bird picture height and its top edge on the screen
W = round(640 * BH / (Y1 - Y0)); PAD = (480 - W) // 2
files = sorted(glob.glob('src/frame_*.gif'))
arrs = []
for f in files:
    im = Image.open(f).convert('RGB').crop((0, Y0, 640, Y1)).resize((W, BH), Image.LANCZOS)
    arrs.append(np.asarray(im).astype(np.float32))
# steady background: per row, median of the edge columns over the frames whose lower band is bluish
edges = [np.concatenate([a[:, :30], a[:, -30:]], axis=1) for a in arrs]
blue = [e for e in edges if e[200:, :, 2].mean() >= e[200:, :, 0].mean()]
ref_rows = np.median(np.concatenate(blue, axis=1), axis=1)            # H x 3
from scipy.ndimage import uniform_filter1d
ref_rows = uniform_filter1d(ref_rows, 9, axis=0)
# full-screen background: the bird's rows at TOPY..TOPY+BH, the darkest bottom colour below, top colour above
full = np.empty((H, 3), np.float32); full[:] = ref_rows[-1]
full[:TOPY] = ref_rows[0]; full[TOPY:TOPY + BH] = ref_rows
from PIL import ImageDraw, ImageFont, ImageFilter
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSerifCondensed-Bold.ttf"
def title_layers():
    S = 3                                                 # draw 3x size, then shrink for smooth edges
    font = ImageFont.truetype(FONT, 40 * S)
    txt = "PHOENIX"
    tmp = ImageDraw.Draw(Image.new('L', (10, 10)))
    bb = tmp.textbbox((0, 0), txt, font=font, stroke_width=S)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    tx = (480 * S - tw) // 2 - bb[0]; ty = (H - 8) * S - th - bb[1]
    fill = Image.new('L', (480 * S, H * S)); ImageDraw.Draw(fill).text((tx, ty), txt, font=font, fill=255)
    edge = Image.new('L', (480 * S, H * S)); ImageDraw.Draw(edge).text((tx, ty), txt, font=font, fill=255, stroke_width=2 * S)
    fill = fill.resize((480, H), Image.LANCZOS); edge = edge.resize((480, H), Image.LANCZOS)
    glow = edge.filter(ImageFilter.GaussianBlur(7))
    return (np.asarray(fill, np.float32) / 255)[..., None], (np.asarray(edge, np.float32) / 255)[..., None], (np.asarray(glow, np.float32) / 255)[..., None]
T_FILL, T_EDGE, T_GLOW = title_layers()
ys = np.linspace(0, 1, H)[:, None, None]
GOLD = np.concatenate([np.full((H, 1, 1), 255.), 235 - 70 * ys, 120 - 90 * ys], axis=2)   # yellow at the top of the letters, orange lower
frames = []
for a in arrs:
    lum = a.max(axis=2)
    alpha = np.clip((lum - 40) / 50, 0, 1)[..., None]                   # 0 = background, 1 = fire/stars
    bg = np.broadcast_to(ref_rows[:, None, :], a.shape)
    out = alpha * a + (1 - alpha) * bg
    canvas = np.broadcast_to(full[:, None, :], (H, 480, 3)).copy()
    canvas[TOPY:TOPY + BH, PAD:PAD + W] = out
    # title: soft orange glow, dark red outline, gold letters
    canvas = canvas * (1 - 0.85 * T_GLOW) + np.array([255, 90, 10]) * 0.85 * T_GLOW
    canvas = canvas * (1 - T_EDGE) + np.array([120, 25, 5]) * T_EDGE
    canvas = canvas * (1 - T_FILL) + GOLD * T_FILL
    frames.append(Image.fromarray(np.clip(canvas, 0, 255).astype(np.uint8)))
for i, fr in enumerate(frames): fr.save('out/phoenix_anim_%02d_480x272.png' % i)
frames[0].save('out/phoenix_anim_preview.gif', save_all=True, append_images=frames[1:], duration=120, loop=0)
sheet = Image.new('RGB', (240 * 3, 136 * 7))
for i, fr in enumerate(frames): sheet.paste(fr.resize((240, 136)), ((i % 3) * 240, (i // 3) * 136))
sheet.save('out/contact_sheet.png')
print(len(frames), 'frames; picture', W, 'px wide, centred')
