PhoenixRPU v41 (Nextion line) - which file to use
Each folder holds one PhoenixRPU.ino. Copy the one you want over the PhoenixRPU.ino in your sketch folder (same libraries as before).

0-COMBINED_button_and_screen  All five rulesets. The push button (left coin door switch, 06) picks the ruleset between games, the Nextion screen shows it.
1-CLASSIC_REBORN              Always plays Classic Reborn. Button does nothing. Screen optional.
2-COMBO_CODES                 Always plays Combo Codes.
3-RACE_THE_CLOCK              Always plays Race the Clock.
4-COMBO_CODES_PLUS_CLOCK      Always plays Combo Codes + Clock.
5-5_EASY                      Always plays 5 EASY (center drop targets A/B = rollovers 1/5).

Single-ruleset builds are the combined file with one line changed: #define FIXED_RULESET n (255 = combined).

NEW IN v41: the number that completes 1-5 does not also count for the next letter (repeat within 1 s ignored).

NEW IN v40: for 60 s after a game the Nextion alternates the iScored QR code and a high-score screen every 3 s.

NEW IN v39: a ball that falls back into the outhole within 2 s of being kicked out is kicked out again, not counted as a drain.

NEW IN v38: steady score display (no flicker; over 1,000,000 scrolls slowly); in Combo Codes the inlanes, kickers and side targets count toward 1-5.

NEW IN v37: the Nextion game screen's top line shows EB n when the player has extra balls waiting.

NEW IN v36: in Combo Codes and Combo Codes + Clock the current PHOENIX letter no longer blinks; letters stay unlit until earned.

NEW IN v35: new attract-mode animation (21 frames in anim/, import them as pictures 2-22 in the Nextion project).

NEW IN v34 (all builds):
- The end-of-ball bonus countdown takes at most 5 seconds.
- Match after the last ball awards one more ball (free play) instead of a credit; the game continues for each matching player.

The credits display shows 41 for 8 seconds at power-up.
V33.E (Waveshare ESP32 panel) is a separate branch and does not have the v34-v41 changes.
